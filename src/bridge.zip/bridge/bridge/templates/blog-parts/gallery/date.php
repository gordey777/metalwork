<div itemprop="dateCreated" class="time entry_date updated">
<span class="time_month"><?php the_time('M'); ?></span>
<span class="time_day"><?php the_time('d'); ?></span>
<span class="time_year"><?php the_time('Y'); ?></span>
<meta itemprop="interactionCount" content="UserComments: <?php echo get_comments_number(qode_get_page_id()); ?>"/>
</div>