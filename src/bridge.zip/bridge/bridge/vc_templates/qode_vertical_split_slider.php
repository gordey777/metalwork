<?php

$html = "";

$html = "<div class='vertical_split_slider'>";
$html .= do_shortcode($content);
$html .= '</div>';

echo $html;

